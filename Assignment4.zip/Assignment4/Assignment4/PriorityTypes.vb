﻿Option Explicit On
Option Strict On

' Created: By Max Åberg 2014-10-26
''' <summary>
''' THe class which contains the different priority Enums
''' </summary>
''' <remarks></remarks>
Public Class PriorityTypes
    Enum priority
        Very_important
        Important
        Normal
        Less_Important
    End Enum

End Class
