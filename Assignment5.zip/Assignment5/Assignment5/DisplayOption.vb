﻿Option Explicit On
Option Strict On

' Created: By Max Åberg 2014-10-30
''' <summary>
''' The class with different preview Enum types
''' </summary>
''' <remarks></remarks>
Public Class DisplayOption
    Enum typeOfSeats
        All_Seats
        Vacant_Seats
        Reserved_Seats
    End Enum

End Class
